<?php 

$config["rg_config"] = "";


?>