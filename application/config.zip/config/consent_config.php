<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
$config['app_name'] = 'Consent Form for PDPA';
